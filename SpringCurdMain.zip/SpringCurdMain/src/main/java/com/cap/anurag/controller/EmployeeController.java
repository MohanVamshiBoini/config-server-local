package com.cap.anurag.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cap.anurag.entities.Employee;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	RestTemplate rest;

	@GetMapping("/find/{id}")
	public Employee getEmployeeById(@PathVariable("id") Integer id) {
		Employee emp=rest.getForObject("http://localhost:7878/employees/find/"+id, Employee.class);
		return emp;
	}

	@SuppressWarnings("unused")
	@RequestMapping("/create")
	public String create(@RequestBody Employee employee) {
		//rest.getForObject("http://localhost:7871/employees/create",Employee.class);
		Employee emp=rest.postForObject("http://localhost:7871/employees/create", employee,Employee.class);
		return "created";
	}

	@RequestMapping("/update")
	public String update(@RequestBody Employee employee) {
		Employee emp=rest.postForObject("http://localhost:7874/employees/update", employee, Employee.class);
		emp.setMessage("Updated");
		return "updated";
	}

	@RequestMapping("/delete/{id}")
	public String deleteEmployeeById(@PathVariable("id") Integer id) {
		rest.getForObject("http://localhost:7872/employees/delete/"+id, Employee.class);
		return "Deleted";
	}

}